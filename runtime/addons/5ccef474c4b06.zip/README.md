### 插件协议
在使用FastAdmin付费插件前认真阅读FastAdmin插件使用协议
https://www.fastadmin.net/page/addon-agreement.html 

### 交流专区
如果你在使用CMS内容管理系统有遇到什么问题，请到FastAdmin交流专区进行交流
https://ask.fastadmin.net/zone/cms.html 

### 温馨提示
此插件为FastAdmin的商业产品，禁止分享、转售、复制CMS插件源码给他人使用，违者将追究法律责任

