<?php

return [
    'User_id'    => '会员ID',
    'Createtime' => '添加时间',
    'Updatetime' => '更新时间',
    'Status'     => '状态'
];
