<?php
return [
    'Upload'      => '上传',
    'Array key'   => '键',
    'Array value' => '值',

];